package P17;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Koneksi {

    // Konstanta konfigurasi database
    private static final String DB_URL = "jdbc:mysql://localhost:3306/db_pamym";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    // Method untuk membuka koneksi
    public static Connection setKoneksi() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Koneksi berhasil");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Koneksi gagal: " + e.getMessage());
        }
        return conn;
    }

    // Method untuk eksekusi INSERT, UPDATE, DELETE
    public static int execute(String SQL) {
        int status = 0;
        try (Connection koneksi = setKoneksi(); Statement st = koneksi.createStatement()) {
            status = st.executeUpdate(SQL);
        } catch (SQLException ex) {
            Logger.getLogger(Koneksi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return status;
    }

    // Method untuk eksekusi SELECT
    public static ResultSet executeQuery(String SQL) {
        ResultSet rs = null;
        try {
            Connection koneksi = setKoneksi();
            Statement st = koneksi.createStatement(
                ResultSet.TYPE_SCROLL_INSENSITIVE, 
                ResultSet.CONCUR_READ_ONLY
            );
            rs = st.executeQuery(SQL);
        } catch (SQLException ex) {
            Logger.getLogger(Koneksi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
    }
}
